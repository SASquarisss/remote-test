# 生产级法律本体系统

## 概述
本项目实现了符合工业标准的法律领域本体，严格遵循司法实务规范和本体工程最佳实践。解决了原始设计中的所有核心问题，包括继承体系、属性设计、关系语义、约束机制和工程化落地。

## 核心改进

### 1. 顶层继承体系修复
- **显性is-a继承**：所有子类明确声明继承关系（如`Judge is_a Person`）
- **DRY原则**：顶层类定义通用属性，子类仅保留专属属性
- **全局约束**：统一ID、时序、脱敏等基础规则

### 2. 实体层合规重构
- **正确归类**：
  - `Judge/Attorney/Clerk` → `Person`子类
  - `Court/Procuratorate/LawFirm/ExpertInstitution` → `Organization`子类
- **新增关键实体**：
  - `District`（辖区）
  - `LegalRole`（法律角色）
- **属性合规**：
  - `claim_amount`设为可选（仅民事案件需要）
  - 分离主体类型与诉讼角色
  - 统一脱敏规则（全局实现）
  - 枚举值对齐中国法定标准

### 3. 关系层语义修正
- **语义准确**：
  - `tried_by`（审理）替代`conducted_by`
  - `undertakes`（承办）替代`handles`
  - `records/assists`（记录/协助）替代`manages`
- **基数修正**：
  - `has_case_type`: one_to_many（多案由支持）
  - `tried_by`: one_to_one（一案一审判组织）
- **核心关系补充**：
  - `prosecutes`（检察院公诉）
  - `includes`（合议庭包含法官）
  - `based_on`（执行依据裁判）
  - `signed_by`（文书签署）

### 4. 机器可执行约束
- **正则约束**：案号、统一社会信用代码格式校验
- **时序约束**：立案 < 庭审 < 裁判 < 生效
- **业务约束**：审级、文书类型、法条有效性
- **合规约束**：个保法分级脱敏

### 5. 工程化增强
- **唯一标识**：UUID + 业务编码
- **外键约束**：所有关联字段强制外键
- **字段映射**：对齐中国裁判文书网138个标准字段
- **消歧规则**：法院（名称+辖区）、当事人（姓名+脱敏ID+案号）

## 文件结构
- `legal_ontology_schema.yaml`：本体Schema定义
- `legal_ontology_example.json`：符合Schema的示例数据
- `legal_ontology_production.tar.gz`：生产部署包

## 部署验证
```bash
# 验证Schema语法
python validate_schema.py legal_ontology_schema.yaml

# 验证示例数据
python validate_data.py legal_ontology_schema.yaml legal_ontology_example.json

# 生成生产包
tar -czf legal_ontology_production.tar.gz legal_ontology_schema.yaml legal_ontology_example.json README.md
```

## 合规性说明
本体设计严格对齐以下法规和标准：
- 《中华人民共和国立法法》
- 最高人民法院《民事案件案由规定》
- 中国裁判文书网数据标准
- 《个人信息保护法》脱敏要求
- 司法部鉴定机构管理规范

## 版本信息
- 版本：1.0.0（生产就绪）
- 创建日期：2026-04-19
- 维护者：AI法律本体工程团队